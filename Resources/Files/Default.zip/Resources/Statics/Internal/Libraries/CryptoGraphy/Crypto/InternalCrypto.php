<?php
//--------------------------------------------------------------------------------------------------
// This file automatically created and updated
//--------------------------------------------------------------------------------------------------

class Crypto extends StaticAccess
{
	const config = 'CryptoGraphy:crypto';

	public static function getClassName()
	{
		return __CLASS__;
	}
}

//--------------------------------------------------------------------------------------------------