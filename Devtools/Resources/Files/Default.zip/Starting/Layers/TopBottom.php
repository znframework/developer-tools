<?php
//--------------------------------------------------------------------------------------------------
// Top Bottom
//--------------------------------------------------------------------------------------------------
//
// Sistemin en üst katmanın bir altında çalıştırılmak istenen kodlar yazılır.
// Sistem sabitleri ve kütüphaneler kullanılabilir. Tüm config yapılandırmalarından önce devreye
// girer. Bu nedenle tüm config yapılandırmalarını bu dosya üzerinden yapabilirsiniz.
//
// Konum
//
// Autoloader'den sonra, Config yapılandırmalarından önce
// 
//--------------------------------------------------------------------------------------------------
