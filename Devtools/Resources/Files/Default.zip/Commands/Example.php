<?php namespace Project\Commands;

use Email;

class Example extends Command
{
    public function send()
    {
        // Email::to('to@example.com')
        //      ->from('from@example.com')
        //      ->subject('Subject')
        //      ->message('Message')
        //      ->send();
    }
}